export const AUTH_CONFIG = {
  domain: 'learnesh.auth0.com',
  clientId: '_2oPGXvDfGddGTC9jLOHHccUNdXcl69L',
  callbackUrl: 'http://localhost:3000/callback'
}
